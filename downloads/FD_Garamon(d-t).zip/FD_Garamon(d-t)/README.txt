GARAMON(D/T)

ABOUT
Garamon(d/t) is a hardcore revival of a revival: the Garamond typeface, published in 1926 by the French Deberny et Peignot type foundry. Itself based on the initial work of sixteenth century French type designer Claude Garamont. Garamon(d/t) is available in two styles: Regular and Italic.
Designed in 2016 by Paul Tubert (https://www.instagram.com/paul.tubert.2015/), published in January 2020 by fonderie.download.

LICENSE
Garamon(d/t) is published under the WTFPL – Do What the Fuck You Want to Public License. For more informations, open the LICENSE.txt file or go to http://www.wtfpl.net/.

ABOUT FONDERIE.DOWNLOAD
We design and distribute typefaces. All our fonts are released under the WTFPL license.

CONTACT
http://www.fonderie.download/
fonderie.download@gmail.com