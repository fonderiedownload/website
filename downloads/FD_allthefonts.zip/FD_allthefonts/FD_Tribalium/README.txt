TRIBALIUM

ABOUT
Tribalium is a font designed to torture your eyes. The font is available in two styles: Regular and Poster. Both styles will be equally useful for your next tattoo idea!
Designed in 2018 by the fonderie.download team, published in january 2020 by fonderie.download.

LICENSE
Tribalium is published under the WTFPL – Do What the Fuck You Want to Public License. For more informations, open the LICENSE.txt file or go to http://www.wtfpl.net/.

ABOUT FONDERIE.DOWNLOAD
We design and distribute typefaces. All our fonts are released under the WTFPL license.

CONTACT
http://www.fonderie.download/
contact@fonderie.download
