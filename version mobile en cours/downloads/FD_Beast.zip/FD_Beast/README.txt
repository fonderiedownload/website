BEAST

ABOUT
Beast is a rebooted font, found inside a forgotten and forgettable video game, developed during the nineties for the Mega Drive. Beast is a serif pixel font with a very short cap height of 5 pixels. This unusual geometry leads to compact letters, clogged apertures, DIY solutions for ligatures and a very weird type color in general. Everything we love at fonderie.download! Published in November 2024 by fonderie.download.

LICENSE
Beast is published under the WTFPL – Do What the Fuck You Want to Public License. For more informations, open the LICENSE.txt file or go to http://www.wtfpl.net/.

ABOUT FONDERIE.DOWNLOAD
We design and distribute typefaces. All our fonts are released under the WTFPL license.

CONTACT
www.fonderie.download
fonderie.download@gmail.com